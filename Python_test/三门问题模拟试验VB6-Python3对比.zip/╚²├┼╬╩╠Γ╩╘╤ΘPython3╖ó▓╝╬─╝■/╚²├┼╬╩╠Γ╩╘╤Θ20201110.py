PROG_LANG = "Python3"  # 编程语言，对比VB和Python
MAX_TEST_TIMES = 1000000  # 最大试验次数，如果显示动态，则为1000次，因为动态显示非常耗时
MAX_TEST_TIMES_DYNAMIC = 1000

import tkinter as tk
from tkinter import *
import os
import time
import random
import webbrowser


class ThreeDoorsTest:
    def __init__(self):
        # ******************************************** 绘制GUI ******************************************
        window = tk.Tk()
        window.title("三门问题模拟试验对比  大系统观-阿色/2020.11")
        window.iconbitmap("三门问题试验\\BSV-LOGO.ico")
        window.resizable(0, 0)
        FRM_Main = tk.Frame(window)
        FRM_Main.grid(row=1, rowspan=2, column=1, padx=20, sticky=S + W + E + N)
        label1 = Label(FRM_Main, text='综合统计结果', font=("宋体", 24, "bold", "underline"), height=3)
        label1.grid(row=1, column=1, columnspan=10)
        label2 = Label(FRM_Main, text="编程语言:", font=("宋体", 18, "bold"), width=8)
        label2.grid(row=2, column=1, columnspan=1, sticky=W)
        label3 = Label(FRM_Main, text=PROG_LANG, width=13, font=("宋体", 18, "bold"), bg="#FFC0C0")
        label3.grid(row=2, column=2, columnspan=1, sticky=W)
        label4 = Label(FRM_Main, text="      你的策略:", font=("宋体", 18, "bold"))
        label4.grid(row=2, column=6, columnspan=2)
        self.LB_Strategy = Label(FRM_Main, text="", width=8, font=("宋体", 18, "bold"), bg="#FFC0C0")
        self.LB_Strategy.grid(row=2, column=8)
        label5 = Label(FRM_Main, text="\n单次试验数据", font=("宋体", 12, "bold"), height=2)
        label5.grid(row=3, column=1, columnspan=4)
        label6 = Label(FRM_Main, text="\n数据统计", font=("宋体", 12, "bold"))
        label6.grid(row=3, column=7, columnspan=2)
        label7 = Label(FRM_Main, text="\n\n（单位：次）", font=("宋体", 10))
        label7.grid(row=3, column=8, columnspan=1)
        label8 = Label(FRM_Main, text="序号 车在门号 选门号 排除门号  换否   结果", font=("宋体", 10, "bold"))
        label8.grid(row=4, column=1, columnspan=4)
        label9 = Label(FRM_Main, text="        1号门  2号门  3号门   合计", font=("宋体", 10, "bold"))
        label9.grid(row=4, column=5, columnspan=4)

        # *************************************** 显示单次试验数据 **********************************************
        SCRB_SD = Scrollbar(FRM_Main)  # 创建Scrollbar组件
        self.TXT_SingleData = tk.Text(FRM_Main, width=44, height=29, padx=5, yscrollcommand=SCRB_SD.set)
        SCRB_SD['command'] = self.TXT_SingleData.yview
        SCRB_SD['width'] = 16
        self.TXT_SingleData.grid(row=5, rowspan=7, column=1, columnspan=4)
        SCRB_SD.grid(row=5, rowspan=7, column=5, sticky=S + W + N)
        SCRB_SD.config(command=self.TXT_SingleData.yview)

        # ************************************* 显示统计数据 ***************************************
        self.TXT_Stat = Text(FRM_Main, width=40, height=5, padx=5)
        self.TXT_Stat.grid(row=5, column=7, columnspan=2)
        label9_1 = Label(FRM_Main, text="\n完成次数", font=("宋体", 16, "bold"))
        label9_1.grid(row=6, column=7, columnspan=4)
        self.LB_TimesFinished = Label(FRM_Main, text="", width=11, font=("宋体", 36, "bold"), bg="#FFC0C0")
        self.LB_TimesFinished.grid(row=7, column=7, columnspan=4)
        label10 = Label(FRM_Main, text="\n得车概率", font=("宋体", 16, "bold"))
        label10.grid(row=8, column=7, columnspan=4)
        self.LB_Prob = Label(FRM_Main, text="", width=11, font=("宋体", 36, "bold"), bg="#FFC0C0")
        self.LB_Prob.grid(row=9, column=7, columnspan=4)
        label12 = Label(FRM_Main, text="\n   计算用时（秒）", font=("宋体", 16, "bold"))
        label12.grid(row=10, column=7, columnspan=4)
        self.LB_TimeLen = Label(FRM_Main, text="", width=11, font=("宋体", 36, "bold"), bg="#FFC0C0")
        self.LB_TimeLen.grid(row=11, column=7, columnspan=4)

        # *************************************** 显示正在计算 ***************************************
        self.FRM_Computing = tk.Frame(window)
        self.LB_Computing = Label(self.FRM_Computing, text="正在计算...", font=("宋体", 48, "bold"), bg="#C0FFC0", height=1,
                                  width=12)

        # ************************************* 输入试验次数、按键 ***********************************
        FRM_TestTimes = Frame(window)
        FRM_TestTimes.grid(row=3, column=1, padx=20, pady=8, sticky=W + E)
        label14 = Label(FRM_TestTimes, text="试验次数：", font=("宋体", 12))
        label14.grid(row=1, column=1)
        self.TotalTestTimes = IntVar(value=1000000)
        self.ETY_TestTimes = Entry(FRM_TestTimes, width=10, textvariable=self.TotalTestTimes)
        self.ETY_TestTimes.grid(row=1, column=2)
        label15 = Label(FRM_TestTimes, text=" *最多1000000次", font=("宋体", 12), width=23)
        label15.grid(row=1, column=3, columnspan=1)
        self.CHK_DynamicShowValue = IntVar(value=0)
        self.CHK_DynamicShow = Checkbutton(FRM_TestTimes, text="显示动态-影响速度，最多1000次", font=("宋体", 12),
                                           variable=self.CHK_DynamicShowValue)
        self.CHK_DynamicShow.grid(row=1, column=4)
        FRM_Buttons = Frame(window)
        FRM_Buttons.grid(row=4, column=1, padx=20, pady=0)
        BT_NoChange = Button(FRM_Buttons, text="每次都不换", width=15, height=3, font=("宋体", 12),
                             command=self.processNoChange)
        BT_NoChange.grid(row=2, column=1)
        BT_Change = Button(FRM_Buttons, text="每次都换", width=15, height=3, font=("宋体", 12),
                           command=self.processChange)
        BT_Change.grid(row=2, column=2)
        BT_Quit = Button(FRM_Buttons, text="不玩了", width=15, height=3, font=("宋体", 12),
                         command=self.processQuit)
        BT_Quit.grid(row=2, column=3)
        BT_SourceCode = Button(FRM_Buttons, text="查看源码/下载", width=15, height=3, font=("宋体", 12),
                               command=self.processSourceCode)
        BT_SourceCode.grid(row=2, column=4)
        label16 = Label(FRM_Buttons, text="\n", font=("宋体", 6))
        label16.grid(row=3, column=1)

        # *********************************** 三门问题介绍 **********************************************
        FRM_Intro = Frame(window, bg="white")
        FRM_Intro.grid(row=1, rowspan=14, column=2, padx=6, pady=6, sticky=W + N)
        label17 = Label(FRM_Intro, text='三 门 问 题', font=("宋体", 28, "bold"), height=2, bg="white")
        label17.grid(row=1, column=1, columnspan=2)
        PIC_Intro = PhotoImage(file="三门问题试验\\三门问题.gif")
        label18 = Label(FRM_Intro, image=PIC_Intro, bg="white")
        label18.grid(row=2, column=1, columnspan=2)
        message = Message(FRM_Intro, text="\n    三门问题是人工智能公司面试时经常提问的问题。它是关于贝叶斯公式的概率论问题。这个仿真模拟验证有助于理解。\n\n"
                                          "   【三门问题描述】\n"
                                          "    这是个猜奖游戏，游戏规则和过程：\n"
                                          "      1、在台上放3扇门，关着。\n"
                                          "      2、主持人随机地分别在门后面放两只羊和一台车。\n"
                                          "      3、你选一扇门，门后的奖品归你。把你的选择告诉主持人。\n"
                                          "      4、主持人在剩下的两扇门中打开一扇后面是羊的门。\n"
                                          "      5、主持人对你说：我已经帮你排除了一扇有羊的门。现在剩下两扇门了。你现在可以选择是否换掉你原来的选择。\n"
                                          "      6、不论你换不换，你所选择的门后的奖品都归你。\n\n"
                                          "    【问题】为了得到车，你换不换？——试试再说！\n\n", font=("宋体", 11), width=500, bg="white")
        message.grid(row=3, column=1, columnspan=2)
        PIC_BSV = PhotoImage(file="三门问题试验\\大系统观logo.gif")
        label19 = Label(FRM_Intro, image=PIC_BSV, bg="white")
        label19.grid(row=4, column=1, sticky=W)
        PIC_BSVQRCode = PhotoImage(file="三门问题试验\\微信公众号二维码200.gif")
        label20 = Label(FRM_Intro, image=PIC_BSVQRCode, bg="white")
        label20.grid(row=4, column=2, sticky=W)
        label21 = Label(FRM_Intro, text='大系统观指导人工智能\n\n', font=("宋体", 14, "bold"), fg="green", bg="white")
        label21.grid(row=5, column=1, columnspan=2)

        # 窗口主循环
        window.mainloop()

    # ******************************************** 处理按键事件 ******************************************
    def processNoChange(self):  # 每次都不换
        Test_Exe(self, "不换")

    def processChange(self):
        Test_Exe(self, "换")

    def processQuit(self):
        os._exit(0)

    def processSourceCode(self):
        url = "https://www.cnblogs.com/BigSystemsView/p/13901753.html"
        webbrowser.open(url)


# ******************************* ThreeDoorsTest类定义结束 ************************************
def InitWinData(win_T, ChangeOrNot):  # 初始化数据
    # 清空数据
    win_T.LB_Strategy["text"] = ""
    win_T.TXT_SingleData.delete('1.0', 'end')  # 清空单次试验数据
    win_T.TXT_Stat.delete('1.0', 'end')  # 清空单次试验数据
    win_T.LB_TimesFinished["text"] = ""
    win_T.LB_Prob["text"] = ""
    win_T.LB_TimeLen["text"] = ""

    TotalTestTimes = win_T.TotalTestTimes.get()
    if win_T.CHK_DynamicShowValue.get() == 0:  # 根据是否显示动态，设定最大实验次数
        if TotalTestTimes > MAX_TEST_TIMES:
            TotalTestTimes = MAX_TEST_TIMES
            win_T.TotalTestTimes.set(MAX_TEST_TIMES)
            win_T.ETY_TestTimes.update()
    else:
        if TotalTestTimes > MAX_TEST_TIMES_DYNAMIC:
            TotalTestTimes = MAX_TEST_TIMES_DYNAMIC
            win_T.TotalTestTimes.set(MAX_TEST_TIMES_DYNAMIC)
            win_T.ETY_TestTimes.update()

    win_T.LB_Strategy["text"] = ChangeOrNot
    if win_T.CHK_DynamicShowValue.get() == 0:  # 如果不显示动态，则显示"正在计算..."提示
        win_T.FRM_Computing.grid(row=1, rowspan=5, column=1)
        win_T.LB_Computing.grid(row=1, column=1, columnspan=10)
        win_T.LB_Computing.update()


def Test_Exe(win_T, ChangeOrNot):
    # 定义并初始化变量
    Door = [0, 0, 0]  # 定义3扇门。          Door[i] = 0：羊，1：车，2：被主持人打开（羊）
    TotalTestTimes = 0  # 试验总次数
    CarNo = SheepNo = YouSelectNo = HostOpenNo = 0  # 车所在门号，羊所在门号，你选择的门号，猜对（得车）次数
    TimesCarDoor = [0, 0, 0]  # 车在各个门的总次数，不可以用连= ，那意味着不同名称指向同一个列表
    TimesYouSelectDoor = [0, 0, 0]  # 你选择各个门的总次数
    TimesHostOpenDoor = [0, 0, 0]  # 主持人打开各个门的总次数
    TimesGetCar = TimesGetSheep = 0  # 得到车的总次数，得到羊的总次数
    Start = Finish = 0  # 计时
    OneRecord = ""  # 单次试验数据记录
    tmpstr = ""

    InitWinData(win_T, ChangeOrNot)  # 窗口数据初始化
    TotalTestTimes = int(win_T.TotalTestTimes.get())
    i_ShowStep = int(TotalTestTimes / 1000)
    if i_ShowStep < 1:
        i_ShowStep = 1

    Time_Start = time.time()
    # =============================== 开始多次模拟试验 ===============================
    for i in range(1, TotalTestTimes + 1):

        # ****************************** 开始一次试验 *****************************
        # 初始化三扇门
        Door = [0, 0, 0]  # 放置三扇门，均放置羊，0代表羊
        CarNo = random.randint(0, 2)  # 主持人随机地把一扇门后面的羊换成车
        Door[CarNo] = 1  # 1代表车
        TimesCarDoor[CarNo] += 1  # 统计每个门放置车的总次数
        OneRecord = str(i) + "\t" + str(CarNo) + "\t"  # 记录每一次的情况

        # 你的第一次选择，你随机选一扇门
        YouSelectNo = random.randint(0, 2)  # 你随机选一扇门
        TimesYouSelectDoor[YouSelectNo] += 1  # 统计每个门被选择的总次数
        OneRecord += str(YouSelectNo) + "\t"  # 记录每一次选择

        # 主持人打开一扇有羊的门
        for j in range(0, 3):
            if j != YouSelectNo and Door[j] == 0:  # 主持人打开你没选且有羊的任何一个门，可以取小号的门
                HostOpenNo = j
                TimesHostOpenDoor[j] += 1
                break
        OneRecord += str(HostOpenNo) + "\t"  # 记录主持人每次打开的门号

        # 你换不换
        OneRecord += ChangeOrNot + "\t"
        if ChangeOrNot == "换":
            if YouSelectNo == 0:
                if HostOpenNo == 1:
                    YouSelectNo = 2
                else:
                    YouSelectNo = 1
            elif YouSelectNo == 1:
                if HostOpenNo == 0:
                    YouSelectNo = 2
                else:
                    YouSelectNo = 0
            elif YouSelectNo == 2:
                if HostOpenNo == 0:
                    YouSelectNo = 1
                else:
                    YouSelectNo = 0

        # 揭晓
        if Door[YouSelectNo] == 1:
            OneRecord += "车*"
            TimesGetCar += 1
        else:
            OneRecord += "羊"
            TimesGetSheep += 1

        # 是否动态显示数据
        if win_T.CHK_DynamicShowValue.get() == 1:
            # 显示单次试验数据记录
            win_T.TXT_SingleData.insert(END, OneRecord + "\n")
            win_T.TXT_SingleData.yview_moveto(1)
            win_T.TXT_SingleData.update()  # 动态更新
            # 显示多次试验的数据统计，没10次刷新一下显示
            if i % 10 == 0:
                win_T.TXT_Stat.delete('1.0', 'end')
                win_T.TXT_Stat.insert(END,
                                      "汽车所在" + "\t" + str(TimesCarDoor[0]) + "\t" + str(TimesCarDoor[1]) + "\t" + str(
                                          TimesCarDoor[2])
                                      + "\t" + str(TimesCarDoor[0] + TimesCarDoor[1] + TimesCarDoor[2]) + "\n")
                win_T.TXT_Stat.insert(END, "第一次选" + "\t" + str(TimesYouSelectDoor[0]) + "\t" + str(
                    TimesYouSelectDoor[1]) + "\t" + str(TimesYouSelectDoor[2])
                                      + "\t" + str(
                    TimesYouSelectDoor[0] + TimesYouSelectDoor[1] + TimesYouSelectDoor[2]) + "\n")
                win_T.TXT_Stat.insert(END,
                                      "主持人开" + "\t" + str(TimesHostOpenDoor[0]) + "\t" + str(
                                          TimesHostOpenDoor[1]) + "\t" + str(
                                          TimesHostOpenDoor[2])
                                      + "\t" + str(
                                          TimesHostOpenDoor[0] + TimesHostOpenDoor[1] + TimesHostOpenDoor[2]) + "\n")
                win_T.TXT_Stat.insert(END, "得车次数" + "\t" + "\t" + "\t" + "\t" + str(TimesGetCar) + "\n")
                win_T.TXT_Stat.insert(END, "得羊次数" + "\t" + "\t" + "\t" + "\t" + str(TimesGetSheep))

                win_T.LB_TimesFinished["text"] = i
                win_T.LB_Prob["text"] = (str(TimesGetCar / i * 100))[0:5] + "%"
                Time_End = time.time()  # 动态显示用时
                win_T.LB_TimeLen["text"] = int(Time_End - Time_Start + 0.5)
        else:
            if i % i_ShowStep == 0:
                tmpstr = tmpstr + OneRecord + "\n"  # 不动态显示时，间隔保存单次试验记录，不间隔的话数据太大，文本框装不下
                # print(i)

        # ****************************** 一次试验结束 *****************************
    # =============================== 多次模拟试验结束 ===============================

    # 不动态显示时，最后显示单次试验记录和最终统计数据
    if tmpstr != "":
        win_T.TXT_Stat.delete('1.0', 'end')
        win_T.TXT_SingleData.insert(END, tmpstr)

    win_T.TXT_Stat.delete('1.0', 'end')
    win_T.TXT_Stat.insert(END, "汽车所在" + "\t" + str(TimesCarDoor[0]) + "\t" + str(TimesCarDoor[1]) + "\t" + str(
        TimesCarDoor[2])
                          + "\t" + str(TimesCarDoor[0] + TimesCarDoor[1] + TimesCarDoor[2]) + "\n")
    win_T.TXT_Stat.insert(END, "第一次选" + "\t" + str(TimesYouSelectDoor[0]) + "\t" + str(
        TimesYouSelectDoor[1]) + "\t" + str(TimesYouSelectDoor[2])
                          + "\t" + str(
        TimesYouSelectDoor[0] + TimesYouSelectDoor[1] + TimesYouSelectDoor[2]) + "\n")
    win_T.TXT_Stat.insert(END,
                          "主持人开" + "\t" + str(TimesHostOpenDoor[0]) + "\t" + str(TimesHostOpenDoor[1]) + "\t" + str(
                              TimesHostOpenDoor[2])
                          + "\t" + str(TimesHostOpenDoor[0] + TimesHostOpenDoor[1] + TimesHostOpenDoor[2]) + "\n")
    win_T.TXT_Stat.insert(END, "得车次数" + "\t" + "\t" + "\t" + "\t" + str(TimesGetCar) + "\n")
    win_T.TXT_Stat.insert(END, "得羊次数" + "\t" + "\t" + "\t" + "\t" + str(TimesGetSheep))

    win_T.LB_TimesFinished["text"] = i
    win_T.LB_Prob["text"] = (str(TimesGetCar / i * 100))[0:5] + "%"
    Time_End = time.time()  # 动态显示用时
    win_T.LB_TimeLen["text"] = int(Time_End - Time_Start + 0.5)

    # 隐藏"正在计算..."提示
    win_T.LB_Computing.grid_forget()
    win_T.FRM_Computing.grid_forget()


# **************************************** 执行主程序 ****************************************
ThreeDoorsTest()
